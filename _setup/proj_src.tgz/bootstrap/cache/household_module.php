<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Household\\Providers\\HouseholdServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Household\\Providers\\HouseholdServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);