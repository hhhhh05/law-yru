<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Aside\\Providers\\AsideServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Aside\\Providers\\AsideServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);